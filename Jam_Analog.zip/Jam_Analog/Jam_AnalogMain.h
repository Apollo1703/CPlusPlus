/***************************************************************
 * Name:      Jam_AnalogMain.h
 * Purpose:   Defines Application Frame
 * Author:     ()
 * Created:   2019-05-02
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef JAM_ANALOGMAIN_H
#define JAM_ANALOGMAIN_H

//(*Headers(Jam_AnalogFrame)
#include <wx/button.h>
#include <wx/combobox.h>
#include <wx/frame.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include <wx/statbmp.h>
#include <wx/stattext.h>
#include <wx/statusbr.h>
//*)

class Jam_AnalogFrame: public wxFrame
{
    public:

        Jam_AnalogFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~Jam_AnalogFrame();

    private:

        //(*Handlers(Jam_AnalogFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnPanel1Paint(wxPaintEvent& event);
        void OnChoice1Select(wxCommandEvent& event);
        void OnButton1Click(wxCommandEvent& event);
        void OnButton2Click(wxCommandEvent& event);
        void OnClose(wxCloseEvent& event);
        void OnSpinButton1Change(wxSpinEvent& event);
        void OnJAMSelected(wxCommandEvent& event);
        void OnMENITSelected(wxCommandEvent& event);
        void OnDetikSelected(wxCommandEvent& event);
        //*)

        //(*Identifiers(Jam_AnalogFrame)
        static const long ID_STATICTEXT1;
        static const long ID_STATICBITMAP1;
        static const long ID_BUTTON1;
        static const long ID_BUTTON2;
        static const long ID_STATICTEXT2;
        static const long ID_COMBOBOX1;
        static const long ID_COMBOBOX2;
        static const long ID_COMBOBOX3;
        static const long ID_STATICTEXT3;
        static const long ID_STATICTEXT4;
        static const long ID_STATICTEXT5;
        static const long ID_PANEL1;
        static const long ID_MENUITEM1;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(Jam_AnalogFrame)
        wxButton* Button1;
        wxButton* Button2;
        wxComboBox* Detik;
        wxComboBox* JAM;
        wxComboBox* MENIT;
        wxPanel* Panel1;
        wxStaticBitmap* StaticBitmap1;
        wxStaticText* StaticText1;
        wxStaticText* StaticText2;
        wxStaticText* StaticText3;
        wxStaticText* StaticText4;
        wxStaticText* StaticText5;
        wxStatusBar* StatusBar1;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // JAM_ANALOGMAIN_H

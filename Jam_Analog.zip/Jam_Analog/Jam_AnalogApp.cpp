/***************************************************************
 * Name:      Jam_AnalogApp.cpp
 * Purpose:   Code for Application Class
 * Author:     ()
 * Created:   2019-05-02
 * Copyright:  ()
 * License:
 **************************************************************/

#include "wx_pch.h"
#include "Jam_AnalogApp.h"

//(*AppHeaders
#include "Jam_AnalogMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(Jam_AnalogApp);

bool Jam_AnalogApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	Jam_AnalogFrame* Frame = new Jam_AnalogFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}

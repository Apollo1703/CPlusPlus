/***************************************************************
 * Name:      Jam_AnalogApp.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2019-05-02
 * Copyright:  ()
 * License:
 ********************************************************/

#ifndef JAM_ANALOGAPP_H
#define JAM_ANALOGAPP_H

#include <wx/app.h>

class Jam_AnalogApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // JAM_ANALOGAPP_H

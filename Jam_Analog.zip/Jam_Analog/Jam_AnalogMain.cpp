/***************************************************************
 * Name:      Jam_AnalogMain.cpp
 * Purpose:   Code for Application Frame
 * Author:     ()
 * Created:   2019-05-02
 * Copyright:  ()
 * License:
 **************************************************************/

#include "wx_pch.h"
#include "Jam_AnalogMain.h"
#include "wx/wx.h"
#include "wx/sizer.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(Jam_AnalogFrame)
#include <wx/bitmap.h>
#include <wx/image.h>
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(Jam_AnalogFrame)
const long Jam_AnalogFrame::ID_STATICTEXT1 = wxNewId();
const long Jam_AnalogFrame::ID_STATICBITMAP1 = wxNewId();
const long Jam_AnalogFrame::ID_BUTTON1 = wxNewId();
const long Jam_AnalogFrame::ID_BUTTON2 = wxNewId();
const long Jam_AnalogFrame::ID_STATICTEXT2 = wxNewId();
const long Jam_AnalogFrame::ID_COMBOBOX1 = wxNewId();
const long Jam_AnalogFrame::ID_COMBOBOX2 = wxNewId();
const long Jam_AnalogFrame::ID_COMBOBOX3 = wxNewId();
const long Jam_AnalogFrame::ID_STATICTEXT3 = wxNewId();
const long Jam_AnalogFrame::ID_STATICTEXT4 = wxNewId();
const long Jam_AnalogFrame::ID_STATICTEXT5 = wxNewId();
const long Jam_AnalogFrame::ID_PANEL1 = wxNewId();
const long Jam_AnalogFrame::ID_MENUITEM1 = wxNewId();
const long Jam_AnalogFrame::idMenuAbout = wxNewId();
const long Jam_AnalogFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(Jam_AnalogFrame,wxFrame)
    EVT_MENU(wxID_ABOUT, Jam_AnalogFrame::OnAbout)
    EVT_MENU(wxID_EXIT, Jam_AnalogFrame::onQuit)
END_EVENT_TABLE()

Jam_AnalogFrame::Jam_AnalogFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(Jam_AnalogFrame)
    wxMenu* Menu1;
    wxMenu* Menu2;
    wxMenuBar* MenuBar1;
    wxMenuItem* MenuItem1;
    wxMenuItem* MenuItem2;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(611,450));
    SetMaxSize(wxSize(611,450));
    Panel1 = new wxPanel(this, ID_PANEL1, wxPoint(280,128), wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    Panel1->SetBackgroundColour(wxColour(12,161,166));
    StaticText1 = new wxStaticText(Panel1, ID_STATICTEXT1, _("JAM ANALOG"), wxPoint(80,24), wxSize(120,19), 0, _T("ID_STATICTEXT1"));
    StaticText1->SetForegroundColour(wxColour(255,255,255));
    StaticText1->SetBackgroundColour(wxColour(255,255,255));
    StaticBitmap1 = new wxStaticBitmap(Panel1, ID_STATICBITMAP1, wxBitmap(wxImage(_T("/home/ekky/Pictures/Walpaper/jam_analog.png")).Rescale(wxSize(344,344).GetWidth(),wxSize(344,344).GetHeight())), wxPoint(264,8), wxSize(344,344), wxSIMPLE_BORDER, _T("ID_STATICBITMAP1"));
    Button1 = new wxButton(Panel1, ID_BUTTON1, _("Start"), wxPoint(16,328), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
    Button1->SetForegroundColour(wxColour(0,0,0));
    Button2 = new wxButton(Panel1, ID_BUTTON2, _("Exit"), wxPoint(120,328), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON2"));
    Button2->SetForegroundColour(wxColour(0,0,0));
    StaticText2 = new wxStaticText(Panel1, ID_STATICTEXT2, _("WAKTU"), wxPoint(96,56), wxDefaultSize, 0, _T("ID_STATICTEXT2"));
    StaticText2->SetForegroundColour(wxColour(255,255,255));
    JAM = new wxComboBox(Panel1, ID_COMBOBOX1, wxEmptyString, wxPoint(128,96), wxDefaultSize, 0, 0, 0, wxDefaultValidator, _T("ID_COMBOBOX1"));
    JAM->Append(_("0"));
    JAM->Append(_("1"));
    JAM->Append(_("2"));
    JAM->Append(_("3"));
    JAM->Append(_("4"));
    JAM->Append(_("5"));
    JAM->Append(_("6"));
    JAM->Append(_("7"));
    JAM->Append(_("8"));
    JAM->Append(_("9"));
    JAM->Append(_("10"));
    JAM->Append(_("11"));
    JAM->Append(_("12"));
    JAM->Append(_("13"));
    JAM->Append(_("14"));
    JAM->Append(_("15"));
    JAM->Append(_("16"));
    JAM->Append(_("17"));
    JAM->Append(_("18"));
    JAM->Append(_("19"));
    JAM->Append(_("20"));
    JAM->Append(_("21"));
    JAM->Append(_("22"));
    JAM->Append(_("23"));
    MENIT = new wxComboBox(Panel1, ID_COMBOBOX2, wxEmptyString, wxPoint(128,144), wxDefaultSize, 0, 0, 0, wxDefaultValidator, _T("ID_COMBOBOX2"));
    MENIT->Append(_("0"));
    MENIT->Append(_("1"));
    MENIT->Append(_("2"));
    MENIT->Append(_("3"));
    MENIT->Append(_("4"));
    MENIT->Append(_("5"));
    MENIT->Append(_("6"));
    MENIT->Append(_("7"));
    MENIT->Append(_("8"));
    MENIT->Append(_("9"));
    MENIT->Append(_("10"));
    MENIT->Append(_("11"));
    MENIT->Append(_("12"));
    MENIT->Append(_("13"));
    MENIT->Append(_("14"));
    MENIT->Append(_("15"));
    MENIT->Append(_("16"));
    MENIT->Append(_("17"));
    MENIT->Append(_("18"));
    MENIT->Append(_("19"));
    MENIT->Append(_("20"));
    MENIT->Append(_("21"));
    MENIT->Append(_("22"));
    MENIT->Append(_("23"));
    MENIT->Append(_("24"));
    MENIT->Append(_("25"));
    MENIT->Append(_("26"));
    MENIT->Append(_("27"));
    MENIT->Append(_("28"));
    MENIT->Append(_("29"));
    MENIT->Append(_("30"));
    MENIT->Append(_("31"));
    MENIT->Append(_("32"));
    MENIT->Append(_("33"));
    MENIT->Append(_("34"));
    MENIT->Append(_("35"));
    MENIT->Append(_("36"));
    MENIT->Append(_("37"));
    MENIT->Append(_("38"));
    MENIT->Append(_("39"));
    MENIT->Append(_("40"));
    MENIT->Append(_("41"));
    MENIT->Append(_("42"));
    MENIT->Append(_("43"));
    MENIT->Append(_("44"));
    MENIT->Append(_("45"));
    MENIT->Append(_("46"));
    MENIT->Append(_("47"));
    MENIT->Append(_("48"));
    MENIT->Append(_("49"));
    MENIT->Append(_("50"));
    MENIT->Append(_("51"));
    MENIT->Append(_("52"));
    MENIT->Append(_("53"));
    MENIT->Append(_("54"));
    MENIT->Append(_("55"));
    MENIT->Append(_("56"));
    MENIT->Append(_("57"));
    MENIT->Append(_("58"));
    MENIT->Append(_("59"));
    Detik = new wxComboBox(Panel1, ID_COMBOBOX3, wxEmptyString, wxPoint(128,192), wxDefaultSize, 0, 0, wxCB_SIMPLE, wxDefaultValidator, _T("ID_COMBOBOX3"));
    Detik->Append(_("1"));
    Detik->Append(_("2"));
    Detik->Append(_("3"));
    Detik->Append(_("4"));
    Detik->Append(_("5"));
    Detik->Append(_("6"));
    Detik->Append(_("7"));
    Detik->Append(_("8"));
    Detik->Append(_("9"));
    Detik->Append(_("10"));
    Detik->Append(_("11"));
    Detik->Append(_("12"));
    Detik->Append(_("13"));
    Detik->Append(_("14"));
    Detik->Append(_("15"));
    Detik->Append(_("16"));
    Detik->Append(_("17"));
    Detik->Append(_("18"));
    Detik->Append(_("19"));
    Detik->Append(_("20"));
    Detik->Append(_("21"));
    Detik->Append(_("22"));
    Detik->Append(_("23"));
    Detik->Append(_("24"));
    Detik->Append(_("25"));
    Detik->Append(_("26"));
    Detik->Append(_("27"));
    Detik->Append(_("28"));
    Detik->Append(_("29"));
    Detik->Append(_("30"));
    Detik->Append(_("31"));
    Detik->Append(_("32"));
    Detik->Append(_("33"));
    Detik->Append(_("34"));
    Detik->Append(_("35"));
    Detik->Append(_("36"));
    Detik->Append(_("37"));
    Detik->Append(_("38"));
    Detik->Append(_("39"));
    Detik->Append(_("40"));
    Detik->Append(_("41"));
    Detik->Append(_("42"));
    Detik->Append(_("43"));
    Detik->Append(_("44"));
    Detik->Append(_("45"));
    Detik->Append(_("46"));
    Detik->Append(_("47"));
    Detik->Append(_("48"));
    Detik->Append(_("49"));
    Detik->Append(_("50"));
    Detik->Append(_("51"));
    Detik->Append(_("52"));
    Detik->Append(_("53"));
    Detik->Append(_("54"));
    Detik->Append(_("55"));
    Detik->Append(_("56"));
    Detik->Append(_("57"));
    Detik->Append(_("58"));
    Detik->Append(_("59"));
    StaticText3 = new wxStaticText(Panel1, ID_STATICTEXT3, _("JAM"), wxPoint(72,104), wxDefaultSize, 0, _T("ID_STATICTEXT3"));
    StaticText4 = new wxStaticText(Panel1, ID_STATICTEXT4, _("MENIT"), wxPoint(72,152), wxDefaultSize, 0, _T("ID_STATICTEXT4"));
    StaticText5 = new wxStaticText(Panel1, ID_STATICTEXT5, _("DETIK"), wxPoint(72,200), wxDefaultSize, 0, _T("ID_STATICTEXT5"));
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, ID_MENUITEM1, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);

    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&Jam_AnalogFrame::OnButton1Click);
    Connect(ID_BUTTON2,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&Jam_AnalogFrame::OnButton2Click);
    Connect(ID_COMBOBOX1,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&Jam_AnalogFrame::OnJAMSelected);
    Connect(ID_COMBOBOX2,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&Jam_AnalogFrame::OnMENITSelected);
    Connect(ID_COMBOBOX3,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&Jam_AnalogFrame::OnDetikSelected);
    Panel1->Connect(wxEVT_PAINT,(wxObjectEventFunction)&Jam_AnalogFrame::OnPanel1Paint,0,this);
    Connect(ID_MENUITEM1,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&Jam_AnalogFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&Jam_AnalogFrame::OnAbout);
    Connect(wxID_ANY,wxEVT_CLOSE_WINDOW,(wxObjectEventFunction)&Jam_AnalogFrame::OnClose);
    //*)
}

Jam_AnalogFrame::~Jam_AnalogFrame()
{
    //(*Destroy(Jam_AnalogFrame)
    //*)
}

void Jam_AnalogFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void Jam_AnalogFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg;
    msg.Printf(wxT('Hello and Welcome to %s')wxVERSION_STRING);
    wxMessageBox(msg, wxT('About Minimal'),wxOK | wxICON_INFORMATION, this);
}

void Jam_AnalogFrame::OnPanel1Paint(wxPaintEvent& event)
{
}

void Jam_AnalogFrame::OnChoice1Select(wxCommandEvent& event)
{
}
void Jam_AnalogFrame::OnButton1Click(wxCommandEvent& event)
{
}

void Jam_AnalogFrame::OnButton2Click(wxCommandEvent& event)
{
    Close();
}

void Jam_AnalogFrame::OnClose(wxCloseEvent& event)
{

}

void Jam_AnalogFrame::OnJAMSelected(wxCommandEvent& event)
{

}
void Jam_AnalogFrame::OnMENITSelected(wxCommandEvent& event)
{

}
void Jam_AnalogFrame::OnDetikSelected(wxCommandEvent& event)
{

}
